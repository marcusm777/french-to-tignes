French to Tignes — Free V1
Open index.html in a modern browser. For microphone recognition on iPhone, the page generally needs to be served over HTTPS rather than opened as a local file.
This prototype uses browser speech recognition and speech synthesis only; it does not perform phoneme-level pronunciation assessment.
Progress is stored locally in the browser.
